#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

main()
{
    int childpid, exitcode;
    char command[20];

    while (1) {
        printf("shell> ");
        scanf("%s", command);
        if ( ! strcmp(command, "exit") )
            exit(0);
        childpid = fork();
        if (childpid == 0) {
            execlp(command, command, 0);
            printf("command not found\n");
            exit(1);
        }
        wait(&exitcode);
    }
}

