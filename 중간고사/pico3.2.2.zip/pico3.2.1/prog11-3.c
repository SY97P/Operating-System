#include <stdio.h>

struct bidMessage {
    int price;
};

int server(int mboxid)
{
    int CurrentPrice = 0;
    struct bidMessage bid;

    while (1) {
        mboxReceive(mboxid, &bid);
        if (bid.price > CurrentPrice) {
            CurrentPrice = bid.price;
            printf("current price is %d\n", CurrentPrice);
        }
    }
}

int bidder(int mboxid)
{
    int myid, count = 0;
    struct bidMessage mybid;

    myid = threadSelf();
    while (count++ < 100) {
        mybid.price = random() % 10000;
        printf("(%d) my bid is %d\n", myid, mybid.price);
        mboxSend(mboxid, &mybid);
        threadYield();
    }
}

//---------------------------------------------------
int userMain(int arg)
{
    int mboxid = mboxCreate();

    srand(getpid());	// set the seed of random number generator

    // the server thread has higher priority than bidder threads
    threadCreate(20, server, mboxid);
    threadCreate(19, bidder, mboxid);
    threadCreate(19, bidder, mboxid);
    threadCreate(19, bidder, mboxid);
}
