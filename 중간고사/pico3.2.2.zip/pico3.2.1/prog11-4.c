#include <stdio.h>

//---------------------------------------------------
void sigHandler(int signum)
{
    printf("Receiver: receive [%d] signal\n", signum);
}

int receiver(int arg)
{
    int signum;

    threadYield();
    for (signum=1; signum <= 2; signum++) {
        signalSet(signum, sigHandler);
        printf("Receiver: set [%d] signal handler\n", signum);
    }

    while (1) {
        printf("Receiver: go his way\n");
        threadYield();
    }
}

int sender(int peer)
{
    int signum, count = 0;
#define SIG_KILL	0	// kill signal

    while (count++ <= 3) {

        for (signum=1; signum <= 3; signum++) {
            printf("Sender: try to send signal (%d)\n", signum);
            signalSend(peer, signum);
            printf("sent.\n");
        }
        threadYield();
    }

    // delay for a moment
    count = 10;
    while (count-- > 0)
        threadYield();

    printf("Sender: try to kill the receiver\n");
    signalSend(peer, SIG_KILL);		// kill the receiver
    printf("done.\n");
}

//---------------------------------------------------
int userMain(int arg)
{
    int thread;

    thread = threadCreate(20, receiver, 0);
    threadCreate(20, sender, thread);
}
