//============================================================
// program 9.2
//============================================================

#include <stdio.h>

#define DATA_SIZE	100
struct sharedBuffer {
    int value[DATA_SIZE];
} sharedData;			// the shared data

//---------------------------------------------------
void writerLock(), writerUnlock(), readerLock(), readerUnlock();

int writer(int index)
{
    int count, myvalue = index * 1000;

    while (1) {	
        printf("Writer [%d] do some action\n", index);

        writerLock();

	myvalue++;

	for (count=0; count < DATA_SIZE/2; count++)
	    sharedData.value[count] = myvalue;
	printf("Writer [%d] <%d ... \n", index, sharedData.value[0]);

	threadYield();

	for (; count < DATA_SIZE; count++)
	    sharedData.value[count] = myvalue;
	printf("... %d> Writer [%d]\n", sharedData.value[DATA_SIZE-1], index);

        writerUnlock();

        printf("Writer [%d] do more action\n", index);

	// sleep for a moment
	{ int count = rand() % 2; while (count-- > 0) threadYield(); }
    }
}

int reader(int index)
{
    int count;

    while (1) {
        printf("        Reader [%d] do some action\n", index);

        readerLock();

	printf("        Reader [%d] <%d ... \n", index, sharedData.value[0]);
	threadYield();
	printf("        ... %d> Reader [%d]\n", sharedData.value[DATA_SIZE-1], index);

        readerUnlock();

        printf("        Reader [%d] do more action\n", index);

	// sleep for a moment
	{ int count = rand() % 5; while (count-- > 0) threadYield(); }
    }
}

//---------------------------------------------------
int semData;				// semaphore for sharedData
int readerCount = 0;			// number of reading threads
int mutexCount;				// mutex for readerCount

void writerLock(void)
{
    semWait(semData);
}

void writerUnlock(void)
{
    semSignal(semData);
}

void readerLock(void)
{
    mutexLock(mutexCount);
    readerCount = readerCount + 1;
    if (readerCount == 1)		// I'm the first reader
        semWait(semData);
    mutexUnlock(mutexCount);
}

void readerUnlock(void)
{
    mutexLock(mutexCount);
    readerCount = readerCount - 1;
    if (readerCount == 0)		// I'm the last reader
        semSignal(semData);
    mutexUnlock(mutexCount);
}

//---------------------------------------------------
int userMain(void)
{
    int count;
#define NUM_READERS	4 	// number of total readers
#define NUM_WRITERS	2	// number of total writers

    // create semaphores
    mutexCount = mutexCreate();
    semData = semCreate(1);

   // create threaders for readers and writers
    for (count=0; count < NUM_READERS; count++)
        threadCreate(20, reader, count);
    for (count=0; count < NUM_WRITERS; count++)
        threadCreate(20, writer, count);
}
