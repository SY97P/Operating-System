// order of mutexes to avoid circular wait : 0 -> 1 -> 2 -> 3

#include <stdio.h>

int mutexInter[4];	// mutexes for the intersection

int turnRight(int corner)
{
    printf("[%d] try to turn right\n", threadSelf());

    mutexLock(mutexInter[corner]);

    printf("[%d] enter the intersection\n", threadSelf());

    threadYield();

    printf("[%d] turn to the right\n", threadSelf());

    threadYield();

    printf("[%d] exit the intersection\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[corner]);

    threadYield();
}

int goStrait(int corner)
{
    int ahead = (corner + 1) % 4;		// the corner of strait ahead

    printf("[%d] try to go strait\n", threadSelf());

    if (ahead < corner)
        mutexLock(mutexInter[ahead]);

    threadYield();

    mutexLock(mutexInter[corner]);

    printf("[%d] enter the intersection\n", threadSelf());

    threadYield();

    if (ahead > corner)
        mutexLock(mutexInter[ahead]);

    printf("[%d] go ahead the intersection\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[corner]);

    threadYield();

    printf("[%d] exit the intersection\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[ahead]);

    threadYield();
}

int turnLeft(int corner)
{
    int ahead = (corner + 1) % 4;		// the corner of strait ahead
    int left = (corner + 2) % 4;		// the corner of left direction

    printf("[%d] try to turn left\n", threadSelf());

    if (ahead < corner)
        mutexLock(mutexInter[ahead]);

    threadYield();

    if (left < corner)
        mutexLock(mutexInter[left]);
   
    threadYield();

    mutexLock(mutexInter[corner]);

    printf("[%d] enter the intersection\n", threadSelf());

    threadYield();

    if (ahead > corner)
        mutexLock(mutexInter[ahead]);

    printf("[%d] go ahead the intersection\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[corner]);

    threadYield();

    if (left > corner)
        mutexLock(mutexInter[left]);

    printf("[%d] turn to the left\n", threadSelf());

    threadYield();

    printf("[%d] go ahead to the left\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[ahead]);

    threadYield();

    printf("[%d] exit the intersection\n", threadSelf());

    threadYield();

    mutexUnlock(mutexInter[left]);

    threadYield();
}

//---------------------------------------------------
// threads of cars
int car(int arg)
{
    int corner, direction;

    while (1) {
        corner = rand() % 4;
        direction = rand() % 3;

	printf("CAR [%d] is on the CORNER %d", threadSelf(), corner);

        if (direction == 0) {
	    printf(" and try to TURN RIGHT\n");
	    turnRight(corner);
	} else if (direction == 1) {
	    printf(" and try to GO STRAIT\n");
	    goStrait(corner);
	} else {
	    printf(" and try to TURN LEFT\n");
	    turnLeft(corner);
	}
    }
}

int userMain(int arg)
{
    int index;

    srand(getpid());

    for (index=0; index < 4; index++)
	mutexInter[index] = mutexCreate();

    for (index=0; index < 10; index++)
	threadCreate(20, car, 0);
}
