//============================================================
// fig. 3.16 
//============================================================

#include <stdio.h>

int userMain(int arg)
{
    int threadBodyA(int), threadBodyB(int);
    
    threadCreate(20, threadBodyA, 0);
    threadCreate(20, threadBodyB, 0);
    threadCreate(20, threadBodyB, 0);
}

int threadBodyA(int arg)
{
    int myid = threadSelf();
    int count = 1;
    
    while(count <= 20) {
	printf("(A%d:%d)", myid, count++);
	threadYield();
    }
}

int threadBodyB(int arg)
{
    int myid = threadSelf();
    int count = 1;
    
    while(count <= 20) {
	printf("(B%d:%d)", myid, count++);
	threadYield();
    }
}
