#include <stdio.h>

#define N	10

// structure of data items
struct dataItem {
    int data;
};

// declaration of the monitor bufferPool
//---------------------------------------------------
typedef struct bufferPool { 
    struct dataItem buffer[N];	// the buffer pool
    int head, tail;		// head and tail indices of the buffer pool
    int count;			// number of items on the buffer pool
    int full;			// condition variable full
    int empty;			// condition variable empty
    int mutex;			// mutex for the monitor bufferPool
} bufferPool;

void bufferPool_putItem(struct dataItem *item, bufferPool *obj)
{
        mutexLock(obj->mutex);		// lock the mutex on entry

        while (obj->count >= N)
            condWait(obj->empty, obj->mutex);

        obj->buffer[obj->tail] = *item;
        obj->tail = (obj->tail + 1) % N;
        obj->count++;

        // wakeup only one thread waiting for full
        condSignal(obj->full);

        mutexUnlock(obj->mutex);	// unlock the mutex on exit
}

void bufferPool_getItem(struct dataItem *item, bufferPool *obj)
{
        mutexLock(obj->mutex);		// lock the mutex on entry

        while (obj->count <= 0)
            condWait(obj->full, obj->mutex);

        *item = obj->buffer[obj->head];
        obj->head = (obj->head + 1) % N;
        obj->count--;

        // wakeup only one thread waiting for empty
        condSignal(obj->empty);

        mutexUnlock(obj->mutex);	// unlock the mutex on exit
}

void bufferPool_initialize(bufferPool *obj)
{
    obj->count = 0;
    obj->head = obj->tail = 0;

    obj->mutex = mutexCreate();
    obj->full = condCreate();
    obj->empty = condCreate();
}

//---------------------------------------------------
// application using the monitor bufferPool

bufferPool buffer;

int producer(int arg)
{
    struct dataItem item;

    while (1) {
        ProduceItemBySomeAction(&item);
      	bufferPool_putItem(&item, &buffer);
    }
}

int consumer(int arg)
{
    struct dataItem item;

    while (1) {
      	bufferPool_getItem(&item, &buffer);
        ConsumeItemForSomeAction(&item);
    }
}

ProduceItemBySomeAction(struct dataItem *item)
{
static int value = 0;

    item->data = value++;
    printf("Produce item (%d)\n", item->data);
}

ConsumeItemForSomeAction(struct dataItem *item)
{
    printf("         Consume item (%d)\n", item->data);
}

//---------------------------------------------------
int userMain(int arg)
{
    bufferPool_initialize(&buffer);

    // create producer and consumer threads
    threadCreate(20, producer, 0);
    threadCreate(20, consumer, 0);
}
