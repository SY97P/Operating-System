#include <stdio.h>

#define N	10

// structure of data items
struct dataItem {
    int data;
} ;

// shared variables
struct dataItem buffer[N]; 			// the circular data buffer
int bufHead = 0, bufTail = 0; 		// index of the head and tail

// semaphores for synchronization
int semFull;				// for synchronization of buffer full
int semEmpty;				// for synchronization of buffer empty

//---------------------------------------------------
int itemSend(struct dataItem *item)
{
    // wait for an empty buffer
    semWait(semEmpty);

    // copy into the circular buffer
    buffer[bufTail] = *item;

    // advance the tail index
    bufTail = (bufTail + 1) % N;

    // signal to the full semaphore
    semSignal(semFull);
}

int itemReceive(struct dataItem *item)
{
    // wait for an available buffer
    semWait(semFull);

    // copy out an item from the circular buffer
    *item = buffer[bufHead];

    // advance the head index
    bufHead = (bufHead + 1) % N;

    // signal to the empty semaphore
    semSignal(semEmpty);
}

//---------------------------------------------------
int producer(int arg)
{
    struct dataItem item;

    while (1) {
        ProduceItemBySomeAction(&item); // produce a new item 
        itemSend(&item);	     	// write item into the shared buffer
    }
}

int consumer(int arg)
{
    struct dataItem item;

    while (1) {
        itemReceive(&item);  	  	 // read item from the shared buffer
        ConsumeItemForSomeAction(&item); // consume the item
    }
}

int ProduceItemBySomeAction(struct dataItem *item)
{
static int value = 0;

    item->data = value++;
    printf("Produce item (%d)\n", item->data);
}

int ConsumeItemForSomeAction(struct dataItem *item)
{
    printf("         Consume item (%d)\n", item->data);
}

//---------------------------------------------------
int userMain(int arg)
{
    // create full semaphore with initial value 0
    semFull = semCreate(0);

    // create empty semaphore with initial value N
    semEmpty = semCreate(N);

   // create producer and consumer threads
    threadCreate(20, producer, 0);
    threadCreate(20, consumer, 0);
}
