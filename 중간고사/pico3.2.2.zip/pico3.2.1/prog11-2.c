#include <stdio.h>

struct dataItem {
    int data;
};

int producer(int mboxid)
{
    struct dataItem item;

    while (1) {
        ProduceItemBySomeAction(&item);		// produce a new item 
        mboxSend(mboxid, &item);   		// send into the mailbox
    }
}

int consumer(int mboxid)
{
    struct dataItem item;

    while (1) {
        mboxReceive(mboxid, &item);  		// receive from the mailbox
        ConsumeItemForSomeAction(&item);	// consume the item
    }
}

ProduceItemBySomeAction(int *item)
{
static int value = 0;

    *item = value++;
    printf("Produce item (%d)\n", *item);
}

ConsumeItemForSomeAction(int *item)
{
    printf("         Consume item (%d)\n", *item);
}

//---------------------------------------------------
int userMain(int arg)
{
    int mboxid = mboxCreate();  	// create a mailbox

    threadCreate(20, producer, mboxid);	// create producer
    threadCreate(20, consumer, mboxid);	// create consumer
}
