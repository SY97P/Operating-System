// mutexes for mutual exclusion of chopsticks

#include <stdio.h>

int mutexChopstick[5];

//---------------------------------------------------
int philosopher(int index)
{
    int left = index;
    int right = (index + 1) % 5;

    while (1) {
        mutexLock(mutexChopstick[left]);
        printf("Philosopher [%d] pickup left chopstick\n", index);
	// threadYield();	// this line results deadlock condition

        mutexLock(mutexChopstick[right]);
        printf("Philosopher [%d] pickup right chopstick\n", index);
	threadYield();

        printf("Philosopher [%d] eat the spaghetti\n", index);
	threadYield();

        printf("Philosopher [%d] putdown left chopstick\n", index);
        mutexUnlock(mutexChopstick[left]);
	threadYield();

        printf("Philosopher [%d] putdown right chopstick\n", index);
        mutexUnlock(mutexChopstick[right]);
	threadYield();

        printf("Philosopher [%d] think about the method to eat\n", index);
	threadYield();
    }
}

//---------------------------------------------------
int userMain(void)
{
    int index;

    // create mutexes for chopsticks
    for (index=0; index < 5; index++)
        mutexChopstick[index] = mutexCreate();

   // create philosophers
    for (index=0; index < 5; index++)
        threadCreate(20, philosopher, index);
}
