//================================================================
//  kernel.c - picoKernel (a simple multi-threading kernel)
//
//  written by Yong-Seok KIM, Kangwon National University, KOREA
//  version 3.2, 2007/01/22
//
//  (c) Copyright Yong-Seok KIM, 1994-2007.  All rights reserved.
//================================================================

#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------
// configuration parameters for the size of kernel resources
//---------------------------------------------------
#define	NUM_THREAD	30	// max number of threads 
#define	PRIO_MIN	0	// minimum thread priority 
#define	PRIO_NORMAL	20	// normal user thread priority 
#define	PRIO_MAX	99	// max thread priority 
#define	STACK_SIZE	4096	// stack size of each thread 

#ifdef KERNEL2 // .........

#define	NUM_MUTEX    	100	// max number of mutexes 
#define	NUM_SEM    	100	// max number of semaphores 
#define	NUM_COND    	20	// max number of condition variables 
#define NUM_MBOX	20	// max number of mailboxes 
#define MBOX_SIZE	10	// max number of messages per mailbox 
#define NUM_REND	30	// max number of rendezvous 
#define	SIG_KILL	0	// kill signal
#define	NUM_SIGNAL	8	// number of signals per thread

#endif // KERNEL2 .........

//---------------------------------------------------

// context related functions
extern void contextSet(unsigned long, unsigned long);
extern void contextSwitch(unsigned long *, unsigned long *);

// declarations of initial system threads 
extern int userMain(int);		// user's main routine 
static int nullMain(int);		// null thread's main routine 

// initialization routines
static int threadInit(void);		// initialize thread entries
#ifdef KERNEL2 // .........
static int condInit(void);		// initialize condition variable
static int mboxInit(void);		// initialize mailbox
static void sigKillHandler(int);	// default KILL signal handler
static int deadlockDetect(void);	// deadlock detection
static void deadlockRecover(void);	// deadlock recovery
static int memInit(void);		// initialize free memory block
int signalSet(int signum, void (*func)(int));
#endif // KERNEL2 .........

// definition of thread entry structure (PCB structure)
enum threadState {STATE_READY, STATE_WAITING};
typedef struct threadEnt {
    struct threadEnt *tNext;		// point to next thread entry 

    enum threadState tState;		// thread state 
    int tPrio;				// thread priority 

    int (*tStart)(int);			// start function address 
    int tArg;				// argument of tStart()

    char *tStack;			// stack base address
    int tStackSize;			// stack size in bytes

    unsigned long tContext;		// address of context area

#ifdef KERNEL2 // .........
    // fields for signal operation
    void (*tSigTab[NUM_SIGNAL])(int);	// handler functions
    unsigned short tSignals;		// signal bits
#endif // KERNEL2 .........

#ifdef PROCESS
    struct procEnt *tProc;		// the process of this thread
    struct threadEnt *tSibling;		// threads of the same process
#endif

} threadEntT;

// declaration of thread table (PCB table)
threadEntT threadTab[NUM_THREAD];

// get thread index from thread entry pointer
#define THREAD_ID(thread)	((thread) - threadTab)

// major kernel variables
static int numThread = 0;		// number of alive threads 
static threadEntT *threadRunning;	// the running thread 
static threadEntT *threadReadyList;	// head of ready thread list 
static threadEntT *threadFreeList;	// head of free thread list 

// scheduling realted functions 
static void schedInsertReady(threadEntT *);
static void schedDeleteRunning(void);
static void schedRunHighest(void);

//---------------------------------------------------
// main -- initialize kernel and become the system thread
//---------------------------------------------------
 
int main()
{
    unsigned long dummy;	// dummy context save address

    // interruptDisable();

    if (kernelInit() < 0)
        return -1;
    bootMessage();

    // interruptEnable();

    // create system threads
    threadCreate(PRIO_MIN, nullMain, 0);	// the null thread
    threadCreate(PRIO_NORMAL+1, userMain, 0);	// the user thread

    // now change to multi-tasking mode
    threadRunning = threadReadyList;
    contextSwitch(&dummy, &threadRunning->tContext);

    // never come here
}

//---------------------------------------------------
// kernelInit -- initialize kernel data structures
//---------------------------------------------------

int kernelInit()
{
#ifdef KERNEL2 // .........
    if (memInit() < 0)		// initialize free memory block
        return -1;
    if (condInit() < 0)		// initialize condition variable
        return -1;
    if (mboxInit() < 0)		// initialize mailbox
        return -1;
#endif // KERNEL2 .........

    if (threadInit() < 0)	// initialize thread
        return -1;

    // HERE, need code to initialize device and
    // interrupt service routines
}

//---------------------------------------------------
// bootMessage -- print welcome message
//---------------------------------------------------

int bootMessage()
{
    printf("\nWelcome to PicoKernel\n\n");
}

//---------------------------------------------------
// nullMain -- null thread (ready forever with the lowest priority)
// return value : (never return)
//---------------------------------------------------
 
static int nullMain(int arg)
{
    while (1) {				// loop forever

        // if there is no more user thread, shutdown PicoKernel
        if (numThread <= 1)
            sysShutdown();

#ifdef KERNEL2 // .........

        // deadlock detection and recovery
        if (deadlockDetect() != 0) {	// deadlock is detected
           printf("deadlock is detected\n");
           deadlockRecover();		// recover from deadlock
        }

#endif // KERNEL2 .........

        threadYield();
    }
}

//---------------------------------------------------
// sysShutdown -- start shutdowm procedure
// return value : (never return)
//---------------------------------------------------
 
int sysShutdown(void)
{
    // display system shutdown message
    printf("\n\nSystem Shutdown ...\n");

    exit(0);	// and shutdown the system
}

//================================================================
// thread management operations
//================================================================

//---------------------------------------------------
// threadInit -- initialize thread entry table
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
static int threadInit(void)
{
#include <alloca.h>		// for stack memory allocation 

    threadEntT *thread;		// point a thread entry 
    int count;			// general index 
    char *stack;		// allocation from stack area 

    // allocate stack memory space
    //stack = (char *)alloca(STACK_SIZE * NUM_THREAD);
    stack = (char *)malloc(STACK_SIZE * NUM_THREAD);
    if (stack == (char *)0)
        return -1;

    // set stack base address and insert all into free list 
    threadFreeList = thread = &threadTab[0];	
    for (count=NUM_THREAD; count > 0; thread++, count--) {
        thread->tStack = stack; thread->tStackSize = STACK_SIZE;
        stack += STACK_SIZE;
        thread->tNext = thread + 1;
    }
    (--thread)->tNext = (threadEntT *)0; // the last entry 

    numThread = 0;			// no alive thread 
    threadRunning = (threadEntT *)0;	// no running thread
    threadReadyList = (threadEntT *)0;	// empty ready list

    return 0;
}

//---------------------------------------------------
// threadStartup -- common startup routine for all threads
// return value : (never return)
//---------------------------------------------------
static void threadStartup(void)
{
    // call the actual start function given on thread creation
    (*(threadRunning->tStart))(threadRunning->tArg);

    // now, return from the start function and want to exit
    threadExit();

    // never come here
}

//---------------------------------------------------
// threadCreate -- create a new thread
// return value : created thread id on success, -1 on fail
//---------------------------------------------------
 
int threadCreate(
    int prio,		// thread priority 
    int (*start)(int),	// start function address 
    int arg		// thread argument
) {
    // unsigned long eflags;
    threadEntT *thread;

    if (prio < PRIO_MIN || prio > PRIO_MAX)  // invalid priority
        return -1;

    // eflags = interruptDisable();

    // allocate a thread entry from free list
    if (threadFreeList == (threadEntT *)0) {  // no more free entry 
        // interruptRestore(eflags);
        return -1;
    }

    thread = threadFreeList;
    threadFreeList = threadFreeList->tNext;  // delete from free list 
    numThread++;			// one more active thread 

    thread->tStart = start;		// thread start function 
    thread->tArg = arg;			// thread argument 
    thread->tPrio = prio;		// thread priority 

    // set initial context (context area is on the bottom of stack)
    thread->tContext = (unsigned long)(thread->tStack)
		+ thread->tStackSize - 208; 		// 24;
    contextSet(thread->tContext, (unsigned long)(threadStartup));

#ifdef KERNEL2 // .........

    // initialize signal handlers as null
  { int index;
    for (index=0; index < NUM_SIGNAL; index++)
        thread->tSigTab[index] = 0;
    // default KILL signal handler
    thread->tSigTab[SIG_KILL] = sigKillHandler;
    thread->tSignals = 0;		// no received signal bit
  }

#endif // KERNEL2 .........

#ifdef PROCESS
    // insert into the thread list of the same process
    thread->tProc = threadRunning->tProc;
    thread->tSibling = threadRunning->tSibling;
    threadRunning->tSibling = thread;
#endif

    // insert into the ready list
    thread->tState = STATE_READY;
    schedInsertReady(thread);

    // reschedule to run the highest priority thread
    if (threadRunning != (threadEntT *)0) 	// initialized
	schedRunHighest();

    // interruptRestore(eflags);
    return THREAD_ID(thread);		// return the thread ID
}

//---------------------------------------------------
// threadExit -- terminate the calling thread
// return value : (never return)
//---------------------------------------------------
 
int threadExit(void)
{
    // interruptDisable();

    // remove the running thread from ready list 
    schedDeleteRunning();

#ifdef PROCESS
  { threadEntT *thread;

    // delete the thread from thread list of the process
    thread = threadRunning->tProc->pThreadList;
    if (thread == threadRunning)
        threadRunning->tProc->pThreadList = threadRunning->tSibling;
    else {
        while (thread->tSibling != threadRunning)
            thread = thread->tSibling; 
        thread->tSibling = thread->tSibling->tSibling; 
    }
    // exit the process if this is the last thread
    if (threadRunning->tProc->pThreadList == (threadEntT *)0)
        procExit();
  }
#endif

    // insert it into free list
    threadRunning->tNext = threadFreeList;
    threadFreeList = threadRunning;

    numThread--;	// decrease the number of alive threads

    // reschedule to run the highest priority thread
    schedRunHighest();

    // never come here
}

//---------------------------------------------------
// threadYield -- yield to the next thread with the same priority
// return value : 0 always
//---------------------------------------------------
 
int threadYield(void)
{
    // unsigned long eflags = interruptDisable();

    // remove the running thread from ready list 
    schedDeleteRunning();

    // reinsert it into ready list 
    schedInsertReady(threadRunning);

    // reschedule to run the highest priority thread
    schedRunHighest();

    // interruptRestore(eflags);
    return 0;
}

//---------------------------------------------------
// threadSelf -- get the id of the  calling (running) thread
// return value : id of the calling thread
//---------------------------------------------------
 
int threadSelf(void)
{
    return THREAD_ID(threadRunning);
}

//================================================================
// scheduling related functions - priority based scheduling
//================================================================

//---------------------------------------------------
// schedInsertReady -- insert into ready list in priority order
// return value : none
//---------------------------------------------------
 
static void schedInsertReady(
    threadEntT *thread		// the thread to be inserted 
) {
    threadEntT *prev, *next;
    int prio = thread->tPrio;

    // find the position to be inserted in decending priority order
    prev = (threadEntT *)0;
    next = threadReadyList;
    while (next != (threadEntT *)0 && next->tPrio >= prio) {
        prev = next;
        next = next->tNext;
    }

    // insert into ready list
    thread->tNext = next;
    if (prev == (threadEntT *)0)
        threadReadyList = thread;
    else
        prev->tNext = thread;
}

//---------------------------------------------------
// schedDeleteRunning -- delete running thread from ready list head
// return value : none
//---------------------------------------------------

static void schedDeleteRunning(void)
{
    // threadRunning is the first thread of ready list
    // remove it from ready list
    threadReadyList = threadReadyList->tNext;
}

//---------------------------------------------------
// schedRunHighest -- reschedule to run the highest priority thread
// return value : none
//---------------------------------------------------
 
static void schedRunHighest(void)
{
    threadEntT *prev, *next;

    prev = threadRunning;
    next = threadReadyList;

    // if the running thread has the highest priority, nothing to do
    if (next == prev)
	return;

#ifdef PROCESS
    if (next->tProc != prev->tProc)
	setPTBR(next->tProc->pPageTable);
#endif

    threadRunning = next;

    // context switch to the new running thread
    contextSwitch(&prev->tContext, &next->tContext);

#ifdef KERNEL2 // .........

    // do signal handler by the receiver 
    if (threadRunning->tSignals != 0) {
    	int signum; unsigned short sigbit = 0x0001;
	for (signum=0; signum < NUM_SIGNAL; signum++) {
	    if (threadRunning->tSignals & sigbit)
            	(*(threadRunning->tSigTab[signum]))(signum);
	    sigbit <<= 1;
	}
    	threadRunning->tSignals = 0;
    }

#endif // KERNEL2 .........

    // the previous thread returns here when dispathced 
}

#ifdef KERNEL2 // .........

#include "kernel2.c"

#endif // KERNEL2 .........
