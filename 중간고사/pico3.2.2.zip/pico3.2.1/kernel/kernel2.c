//================================================================
// kernel2.c - mutex, semaphore, condition variable, mailbox
//             rendezvous, signal, deadlock
//================================================================

//================================================================
// mutex management operations
//================================================================

// definition of the mutex entry structure 
typedef struct mutexEnt {
    threadEntT *mHead, *mTail;	// head and tail of waiting queue
    threadEntT *mOwner;		// mutex owner (the locking thread) 
} mutexEntT;

static mutexEntT mutexTab[NUM_MUTEX];	// the mutex table
static int mutexNextFree = 0;		// index of next free mutex

//---------------------------------------------------
// mutexCreate -- create a new mutex
// return value : created mutex id on success, -1 on fail
//---------------------------------------------------
 
int mutexCreate(void)
{
    // unsigned long eflags;
    int mutexid;

    if (mutexNextFree >= NUM_MUTEX)	// no more free entry
        return -1;

    // eflags = interruptDisable();

    // allocate a free mutex entry 
    mutexid = mutexNextFree++;

    // initialize attributes
    mutexTab[mutexid].mOwner = (threadEntT *)0;
    mutexTab[mutexid].mHead = (threadEntT *)0;

    // interruptRestore(eflags);

    return mutexid;
}

//---------------------------------------------------
// mutexLockAux -- internal implementation of lock operation
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
static int mutexLockAux(
    int mutexid,	// muted id
    int trylock		// nonblocking mode flag
) {
    // unsigned long eflags;
    mutexEntT *mutex;

    if (mutexid < 0 || mutexid >= mutexNextFree) // invalid mutex id 
        return -1;

    // eflags = interruptDisable();

    mutex = &mutexTab[mutexid];
    while (mutex->mOwner != (threadEntT *)0) {	// locked by other
    	if (trylock != 0) {
            // interruptRestore(eflags);
	    return -1;
	}
    	// remove the running thread from ready list 
    	schedDeleteRunning();

    	// insert into waiting thread list
    	threadRunning->tState = STATE_WAITING;
    	if (mutex->mHead == (threadEntT *)0) {
            mutex->mHead = mutex->mTail = threadRunning;
    	} else {
            mutex->mTail->tNext = threadRunning;
            mutex->mTail = threadRunning;
    	}
    	threadRunning->tNext = (threadEntT *)0;

    	// reschedule to run the highest priority thread
    	schedRunHighest();
    }

    // interruptRestore(eflags);
    mutex->mOwner = threadRunning;	// become the owner 

    // interruptRestore(eflags);
    return 0;
}

//---------------------------------------------------
// mutexLock -- lock operation on a mutex
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int mutexLock(int mutexid)
{
    return mutexLockAux(mutexid, 0);
}

//---------------------------------------------------
// mutexTryLock -- try lock operation on a mutex
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int mutexTryLock(int mutexid)
{
    return mutexLockAux(mutexid, 1);
}

//---------------------------------------------------
// mutexUnlock -- unlock operation on a mutex
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int mutexUnlock(
    int mutexid		// mutex id 
) {
    // unsigned long eflags;
    mutexEntT *mutex;
    threadEntT *thread;

    if (mutexid < 0 || mutexid >= mutexNextFree) // invalid mutex id 
        return -1;

    mutex = &mutexTab[mutexid];

    if (mutex->mOwner != threadRunning)		// not the owner
        return -1;

    // eflags = interruptDisable();

    mutex->mOwner = (threadEntT *)0;		// no owner 

    if (mutex->mHead != (threadEntT *)0) {	// exist waiting threads
    	// wakeup the first waiting thread (FCFS)

    	// remove the first thread from waiting list
    	thread = mutex->mHead;
    	mutex->mHead = thread->tNext;

    	// insert into the ready list
    	thread->tState = STATE_READY;
    	schedInsertReady(thread);

    	// reschedule to run the highest priority thread
    	schedRunHighest();
    }

    // interruptRestore(eflags);
    return 0;
}

//================================================================
// semaphore management operations - counting semaphore
//================================================================

// definition of semaphore entry structure 
typedef struct semEnt {
    int sValue;			// semaphore value 
    threadEntT *sHead, *sTail;	// head and tail of waiting list 
} semEntT;

static semEntT semTab[NUM_SEM]; // semaphore table 
static int semNextFree = 0;	// index of the next free semaphore

//---------------------------------------------------
// semCreate -- create a new semaphore
// return value : the created semaphore id on success, -1 on fail
//---------------------------------------------------
 
int semCreate(
    int value		// initial semaphore value 
) {
    // unsigned long eflags;
    int semid;

    // invalid initial value or no more free entry
    if (value < 0 || semNextFree >= NUM_SEM)
        return -1;

    // eflags = interruptDisable();

    // allocate a free semaphore entry 
    semid = semNextFree++;

    // initialize the entry
    semTab[semid].sValue = value;		// initial value 
    semTab[semid].sHead = (threadEntT *)0;	// empty waiting list 

    // interruptRestore(eflags);
    return (semid);
}

//---------------------------------------------------
// semWait -- wait operation on a semaphore
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int semWait(
    int semid		// semaphore id 
) {
    // unsigned long eflags;
    semEntT *sem;

    if (semid < 0 || semid >= semNextFree)	// invalid id 
        return -1;

    // eflags = interruptDisable();

    sem = &semTab[semid];
    while (sem->sValue <= 0) {			// not available 
    	// remove the running thread from ready list 
    	schedDeleteRunning();

    	// insert into waiting thread list
    	threadRunning->tState = STATE_WAITING;
    	if (sem->sHead == (threadEntT *)0) {
            sem->sHead = sem->sTail = threadRunning;
    	} else {
            sem->sTail->tNext = threadRunning;
            sem->sTail = threadRunning;
    	}
    	threadRunning->tNext = (threadEntT *)0;

    	// reschedule to run the highest priority thread
    	schedRunHighest();
    }
    sem->sValue--;			// decrement the value 

    // interruptRestore(eflags);
    return 0;
}

//---------------------------------------------------
// semSignal -- signal operation on a semaphore
// return value : 0n on success, -1 on fail
//---------------------------------------------------
 
int semSignal(
    int semid		// semaphore id 
) {
    // unsigned long eflags;
    semEntT *sem;
    threadEntT *thread;

    if (semid < 0 || semid >= semNextFree)	// invalid id 
        return -1;

    // eflags = interruptDisable();

    sem = &semTab[semid];
    sem->sValue++;			// increment the value 

    if (sem->sValue > 0 && sem->sHead != (threadEntT *)0) {
    	// wakeup the first waiting thread (FCFS)

    	// remove the first thread from waiting list
    	thread = sem->sHead;
    	sem->sHead = thread->tNext;

    	// insert into the ready list
    	thread->tState = STATE_READY;
    	schedInsertReady(thread);

    	// reschedule to run the highest priority thread
    	schedRunHighest();
    }

    // interruptRestore(eflags);
    return 0;
}

//---------------------------------------------------
// semValue -- return the current semaphore value
// return value : current semaphore value on success, -1 on fail
//---------------------------------------------------
 
int semValue(
    int semid		// semaphore id 
) {
    if (semid < 0 || semid >= semNextFree) // invalid id 
        return -1;

    return (semTab[semid].sValue);	   // return the value 
}

//================================================================
// condition variable management operations
//================================================================

// definition of condition variable entry structure 
typedef struct condEnt {
    int cCount;			// number of waiting threads
    int cSem;			// semaphore to synchronize
} condEntT;

static condEntT condTab[NUM_COND];	// condition variable table 
static int condNextFree = 0;		// index of next free entry
static int condMutex;		// mutex to protect cond. var. table

//---------------------------------------------------
// condInit -- initialize variables for condition variable
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int condInit(void)
{
    condMutex = mutexCreate();
    if (condMutex < 0)
        return -1;
    return 0;
}

//---------------------------------------------------
// condCreate -- create a new condition variable
// return value : created cond. var. id on success, -1 on fail
//---------------------------------------------------
 
int condCreate(void)
{
    int condid;

    if (condNextFree >= NUM_COND)	// no more free entry
        return -1;

    mutexLock(condMutex);

    // allocate a free condition variable entry 
    condid = condNextFree++;

    // initialize the entry
    condTab[condid].cCount = 0;
    condTab[condid].cSem = semCreate(0);

    mutexUnlock(condMutex);

    return (condid);
}

//---------------------------------------------------
// condWait -- wait operation on a condition variable
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int condWait(
    int condid,			// condition variable id 
    int mutexid			// monitor mutex id
) {
    condEntT *cond;

    if (condid < 0 || condid >= condNextFree)	// invalid id 
        return -1;

    cond = &condTab[condid];
    
    mutexLock(condMutex);

    // increment the waiting count
    cond->cCount++;

    // unlock the monitor mutex
    if (mutexUnlock(mutexid) < 0) {		// not the owner
        cond->cCount--;
        mutexUnlock(condMutex);
        return -1;
    }

    mutexUnlock(condMutex);

    // wait until signaling by sombody
    semWait(cond->cSem);

    // lock again the monitor mutex
    mutexLock(mutexid);

    return 0;
}

//---------------------------------------------------
// condSignal -- signal operation on a condition variable
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int condSignal(
    int condid			// condition variable id 
) {
    condEntT *cond;

    if (condid < 0 || condid >= condNextFree)	// invalid id 
        return -1;

    cond = &condTab[condid];

    mutexLock(condMutex);

    if (cond->cCount > 0) {	// waiting list is not empty
        cond->cCount--;		// decrement the waiting count
        semSignal(cond->cSem);	// signal to wakeup one thread
    }

    mutexUnlock(condMutex);

    return 0;
}

//================================================================
// mailbox management operations - message type is fixed as int 
//================================================================

// definition of mailbox entry structure 
typedef struct mboxEnt {
    int mEmpty, mFull;		// semaphore for empty and full 
    int mHead, mTail;		// indeices of of the buffer
    int mBuffer[MBOX_SIZE];	// circular message buffer 
} mboxEntT;

static mboxEntT mboxTab[NUM_MBOX];	// mailbox table
static int mboxNextFree = 0;		// next free mailbox
static int mboxMutex;		// mutex to protect mailbox table

//---------------------------------------------------
// mboxInit -- initialize variables for mailbox
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int mboxInit(void)
{
    mboxMutex = mutexCreate();	// to protect mailbox table
    if (mboxMutex < 0)
        return -1;
    return 0;
}

//---------------------------------------------------
// mboxCreate -- create a new mailbox
// return value : created mailbox id on success, -1 on fail
//---------------------------------------------------
 
int mboxCreate(void)
{
    mboxEntT *mbox;
    int mboxid;

    if (mboxNextFree >= NUM_MBOX)	// no more free entry
        return -1;

    mutexLock(mboxMutex);

    // allocate a free mailbox entry 
    mboxid = mboxNextFree;
    mbox = &mboxTab[mboxid];

    mbox->mHead = mbox->mTail = 0;	// index of head and tail 

    // create related semaphores
    mbox->mEmpty = semCreate(MBOX_SIZE); // number of empty buffers 
    mbox->mFull = semCreate(0);		// number of messages 

    if (mbox->mEmpty < 0 || mbox->mFull < 0) {	// some error
        mutexUnlock(mboxMutex);
        return -1;
    }
    mboxNextFree++;

    mutexUnlock(mboxMutex);

    return (mboxid);
}

//---------------------------------------------------
// mboxSend -- send a message to a mailbox
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int mboxSend(
    int mboxid,		// mailbox id 
    int *msgp		// buffer of the message to be sent 
) {
    mboxEntT *mbox;

    if (mboxid < 0 || mboxid >= mboxNextFree)	// invalid id 
        return -1;

    mbox = &mboxTab[mboxid];

    // wait for a free message buffer
    semWait(mbox->mEmpty);

    mutexLock(mboxMutex);

    // save the message on the tail of message buffer
    mbox->mBuffer[mbox->mTail] = *msgp;

    // advance the tail of the circular buffer
    mbox->mTail++;
    if (mbox->mTail >= MBOX_SIZE)
	mbox->mTail = 0;

    mutexUnlock(mboxMutex);

    // signal to notify the added message
    semSignal(mbox->mFull);

    return 0;
}

//---------------------------------------------------
// mboxReceive -- receive a message from a mailbox
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int mboxReceive(
    int mboxid,		// mailbox id 
    int *msgp		// buffer to store the received message 
) {
    mboxEntT *mbox;

    if (mboxid < 0 || mboxid >= mboxNextFree)	// invalid id 
        return -1;

    mbox = &mboxTab[mboxid];

    // wait for a stored message
    semWait(mbox->mFull);

    mutexLock(mboxMutex);

    // copy out a message
    *msgp = mbox->mBuffer[mbox->mHead];

    // advance the head of the circular buffer
    mbox->mHead++;
    if (mbox->mHead >= MBOX_SIZE)
	mbox->mHead = 0;

    mutexUnlock(mboxMutex);

    // signal to notify one more free message buffer
    semSignal(mbox->mEmpty);

    return 0;
}

//---------------------------------------------------
// mboxCount -- return the number of messages on a mailbox
// return value : number of messages on success, -1 on fail
//---------------------------------------------------
 
int mboxCount(
    int mboxid		// mailbox id 
) {
    if (mboxid < 0 || mboxid >= mboxNextFree)	// invalid id 
        return -1;

    return (semValue(mboxTab[mboxid].mFull));
}

//================================================================
// rendezvous management operations - message type is fixed as int 
//================================================================

// definition of rendezvous entry structure 
typedef struct rendEnt {
    int rSender, rReceiver;	// the sender and receiver
    int rReady, rDone;    	// semaphore for rendezvous
    int *rMsgAddr;  		// buffer address to receive
} rendEntT;

rendEntT rendTab[NUM_REND];	// declaration of rendezvous table
static int rendNextFree = 0;	// next free rendezvous entry

//---------------------------------------------------
// rendCreate -- create a new rendezvous
// return value : created rendezvous id on success, -1 on fail
//---------------------------------------------------

int rendCreate(int sender, int receiver)
{
    rendEntT *rend;
    int rendid;

    if (rendNextFree >= NUM_REND)	// no more free entry
        return -1;

    rendid = rendNextFree;		// allocate a free entry 
    rend = &rendTab[rendid];

    rendTab[rendid].rSender = sender;
    rendTab[rendid].rReceiver = receiver;

    rendTab[rendid].rReady = semCreate(0);
    rendTab[rendid].rDone = semCreate(0);

    rendTab[rendid].rMsgAddr = (int *)0;

    if (rend->rSender < 0 || rend->rReceiver < 0)	// some error
        return -1;

    rendNextFree++;

    return rendid;
}

//---------------------------------------------------
// rendSend -- send a message to a rendezvous
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int rendSend(
    int rendid,		// rendezvous id
    int *msg		// message buffer
) {
    rendEntT *rend = &rendTab[rendid];

    if (rendid < 0 || rendid >= rendNextFree)	// invalid id 
        return -1;

    if (threadSelf() != rend->rSender)
        return -1;

    semWait(rend->rReady);	    	// wait until receiver is ready
    *(rend->rMsgAddr) = *msg;  		// copy the message
    semSignal(rend->rDone);    		// wakeup the receiver
}

//---------------------------------------------------
// rendReceive -- receive a message from a rendezvous
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int rendReceive(
    int rendid,		// rendezvous id
    int *msg		// message buffer
) {
    rendEntT *rend = &rendTab[rendid];

    if (rendid < 0 || rendid >= rendNextFree)	// invalid id 
        return -1;

    if (threadSelf() != rend->rReceiver)
        return -1;
 
    rend->rMsgAddr = msg;	// save the message buffer
    semSignal(rend->rReady);   	// notify that receiver is ready
    semWait(rend->rDone);	// wait until message copy is done
}

//================================================================
// signal handling
//================================================================

//---------------------------------------------------
// sigKillHandler -- default kill signal handler
// return value : never return
//---------------------------------------------------

static void sigKillHandler(int signum)
{
    threadExit();
}

//---------------------------------------------------
// signalSet -- register handler function for a signal
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int signalSet(
    int signum,			// signal number
    void (*func)(int)		// handler function
) {
    if (signum < 0 || signum >= NUM_SIGNAL)	// invalid numner
        return -1;

    threadRunning->tSigTab[signum] = func;
    return 0;
}

//---------------------------------------------------
// signalSend -- send a signal to a thread
// return value : 0 on success, -1 on fail
//---------------------------------------------------

int signalSend(
    int thid,			// destination thread id
    int signum			// signal number
) {
    threadEntT *thread;
    unsigned long *sp;		// stack address
    int index;

    if (signum < 0 || signum >= NUM_SIGNAL)	// invalid numner
        return -1;
    if (thid < 0 || thid >= NUM_THREAD)		// invalid thread
        return -1;

    thread = &threadTab[thid];

    if ( ! thread->tSigTab[signum])		// no signal handler
        return 0;

    if (thread == threadRunning) {		// signal itself
        (*(threadTab->tSigTab[signum]))(signum);
        return 0;
    }
    thread->tSignals |= (1 << signum);

    return 0;
}

//================================================================
// deadlock detection and recovery
//================================================================

//---------------------------------------------------
// deadlockDetect -- detect deadlock (check a cycle on WFG)
// return value : 0 on no deadlock, 1 on detecting a deadlock
//---------------------------------------------------
static int deadlockDetect(void)
{
    int WFG[NUM_THREAD];	// wait-for graph
    int group[NUM_THREAD];	// to check a cycle
    int index, index2;
    threadEntT *thread;

    // make the wait-for graph
    for (index=0; index < NUM_THREAD; index++)
        WFG[index] = -1;
    for (index=0; index < NUM_MUTEX; index++) {
        if (mutexTab[index].mOwner == (threadEntT *)0)
            continue;
        index2 = THREAD_ID(mutexTab[index].mOwner);
	 thread = mutexTab[index].mHead;
	 while (thread != (threadEntT *)0) {
	     WFG[ THREAD_ID(thread) ] = index2;
	     thread = thread->tNext;
	 }
    }

    // detect a cycle of the wait-for graph
    for (index=0; index < NUM_THREAD; index++)
	group[index] = -1;
    for (index=0; index < NUM_THREAD; index++) {
        if (group[index] != -1)		// visited already
            continue;
        group[index] = index;
        index2 = WFG[index];
        while (index2 != -1) {
            if (group[index2] == index)	// a cycle is detected
                return 1;
            if (group[index2] != -1)	// visited already
                break;
            group[index2] = index;
            index2 = WFG[index2];
        }
    }
    return 0;				// there is no cycle
}

//---------------------------------------------------
// deadlockRecover -- recovery from deadlock condition
// return value : never return
//---------------------------------------------------
static void deadlockRecover(void)
{
    // simply shutdown the system
    sysShutdown();
}

//================================================================
// memory allocation operations - use first-fit allocation
//================================================================
 
#define MEM_AREASIZE	100000	// 100 kilo-bytes memory area 
static char _memArea[MEM_AREASIZE];
static char *memStart = _memArea;
static char *memEnd = &_memArea[MEM_AREASIZE];

typedef struct memEnt {	// memory block entry structure 
    struct memEnt *mNext;	// the next block address 
    int mSize;			// the block size 
} memEntT;

// NOTE) the size of memEntT is 8 bytes

static int memMutex;		// mutex to protect free memory block list
static memEntT *memFreeList;	// free memory block entry list 

// NOTE) free memory block list is maintained in increasing address order

//---------------------------------------------------
// memInit -- initialize memory block entry list
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
static int memInit(void)
{
    memMutex = mutexCreate();
    if (memMutex < 0)
        return -1;

    // align addresses in 8 bytes boundary
    memEnd = (char *)((unsigned long)memEnd & ~7);
    memStart = (char *)(((unsigned long)memStart + 7) & ~7);

    // a trick for simple memory management code
    memFreeList = (memEntT *)memStart;
    memStart += 8;
    memFreeList->mSize = 0;		
    memFreeList->mNext = (memEntT *)memStart;

    // set the whole memory area as a big free memory block
    memFreeList->mNext->mSize = memEnd - memStart;	
    memFreeList->mNext->mNext = (memEntT *)0;	// end of list 

    printf("Free Memory : 0x%x - 0x%x (%d bytes)\n\n",
	    memStart, memEnd, memEnd - memStart);

    return 0;
}

//---------------------------------------------------
// memAlloc -- allocate a free memory block
// return value : memory address on success, NULL on fail
//---------------------------------------------------
 
void *memAlloc(
    int size			// requested memory size 
) {
    memEntT *prev, *memp;

    if (size <= 0)
	return ((char *)0);

    size += sizeof(int);	// space to save the size 
    size = (size + 7) & ~7;	// align in 8 bytes boundary 

    mutexLock(memMutex);

    // find the first free memory block satisfying the size
    prev = memFreeList;
    for (memp = prev->mNext; memp != (memEntT *)0;
		memp = memp->mNext) {
	if (memp->mSize >= size)	// find the first-fit 
	    break;
	prev = memp;
    }
    if (memp == (memEntT *)0) {	// can't find an enough block
        mutexUnlock(memMutex);
	return ((char *)0);
    }

    // remove the block from free memory block list
    if (memp->mSize <= size + 8) {	// allocate the whole block
	prev->mNext = memp->mNext;
        size = memp->mSize;		// add an internal fragment
    } else {				// divide the free block
    	prev->mNext = (memEntT *)((char *)memp + size);
    	prev->mNext->mNext = memp->mNext;
    	prev->mNext->mSize = memp->mSize - size;
    }
    *(int *)memp = size;		// save the allocated size 

    mutexUnlock(memMutex);

    return ((char *)memp + sizeof(int));
}

//---------------------------------------------------
// memFree -- deallocate a memory block
// return value : 0 on success, -1 on fail
//---------------------------------------------------
 
int memFree(
    void *addr			// memory address to be deallocated
) {
    memEntT *prev, *memp;
    int size;
    char *addr2;
    
    addr2 = (char *)addr - sizeof(int);
    if (addr2 < memStart || addr2 > memEnd)	// invalid address 
	return -1;

    size = *(int *)addr2;		// restore allocated size 
    
    if (size < 8 || addr2 + size > memEnd)	// invalid size 
	return -1;

    mutexLock(memMutex);

    // find the position on free list in increasing address order
    prev = memFreeList;	
    for (memp = prev->mNext; memp != (memEntT *)0;
		memp = memp->mNext) {
	if ((char *)(memp) > addr2)
	    break;
	prev = memp;
    }

    // check validity of the address and size
    if ((char *)prev + prev->mSize > addr2 ||
	(memp != (memEntT *)0 && (addr2 + size) > (char *)memp)) {
        mutexUnlock(memMutex);
	return -1;
    }

    // insert the block into free memory block list

    if ((char *)prev + prev->mSize == addr2) {
       	// merge with the previous block 
	prev->mSize += size;
    } else {
        // insert a free memory block
	prev->mNext = (memEntT *)addr2;
	prev = (memEntT *)addr2;
	prev->mSize = size;
	prev->mNext = memp;
    }
    if ((char *)prev + prev->mSize == (char *)memp) {
        // merge with the next block 
	prev->mSize += memp->mSize;
	prev->mNext = memp->mNext;
    }

    mutexUnlock(memMutex);

    return 0;
}
