//============================================================
// program 9.1
//============================================================

#include <stdio.h>

#define N	10

// structure of data items
struct dataItem {
    int data;
};

// shared variables
struct dataItem buffer[N];		// the circular data buffer
int bufHead = 0, bufTail = 0; 		// head and tail indices of the buffer

// semaphores for synchronization
int semFull;				// for synchronization of buffer full
int semEmpty;				// for synchronization of buffer empty

//---------------------------------------------------
int producer(int arg)
{
    struct dataItem item;

    while (1) {	// loop forever
        // produce a new item by some action
        ProduceItemBySomeAction(&item);

        // wait for an empty buffer
        semWait(semEmpty);

        // copy into the circular buffer
        buffer[bufTail] = item;

        // advance the tail index
        bufTail = (bufTail + 1) % N;

        // signal to the full semaphore
        semSignal(semFull);
    }
}

//---------------------------------------------------
int consumer(int arg)
{
    struct dataItem item;

    while (1) {				// loop forever
        // wait for an available buffer
        semWait(semFull);

        // copy out an item from the circular buffer
        item = buffer[bufHead];

        // advance the head index
        bufHead = (bufHead + 1) % N;

        // signal to the empty semaphore
        semSignal(semEmpty);

        // consume th item for some action
        ConsumeItemForSomeAction(&item);
    }
}

ProduceItemBySomeAction(struct dataItem *item)
{
static int value = 0;

    item->data = value++;
    printf("Produce item (%d)\n", item->data);
}

ConsumeItemForSomeAction(struct dataItem *item)
{
    printf("         Consume item (%d)\n", item->data);
}

//---------------------------------------------------
int userMain(int arg)
{
    // create full semaphore with initial value 0
    semFull = semCreate(0);

    // create empty semaphore with initial value N
    semEmpty = semCreate(N);

   // create producer and consumer threads
    threadCreate(20, producer, 0);
    threadCreate(20, consumer, 0);
}
